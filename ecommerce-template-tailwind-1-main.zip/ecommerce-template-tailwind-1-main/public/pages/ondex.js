import { Offcanvas } from 'flowbite-tailwind'

const offcanvasExample = document.getElementById('offcanvasExample')
const offcanvas = new Offcanvas(offcanvasExample)
